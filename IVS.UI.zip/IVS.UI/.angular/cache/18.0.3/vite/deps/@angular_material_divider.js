import {
  MatDivider,
  MatDividerModule
} from "./chunk-AEUZGOUA.js";
import "./chunk-EKFIT3H3.js";
import "./chunk-YPGFEGVV.js";
import "./chunk-U6T465MX.js";
import "./chunk-26IGLY6R.js";
import "./chunk-R7GQRDZ6.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
