import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-WRRGHVSA.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-A72QZBXG.js";
import "./chunk-PIGU46RQ.js";
import "./chunk-SELNNJZN.js";
import "./chunk-QARGB7X4.js";
import "./chunk-EKFIT3H3.js";
import "./chunk-YPGFEGVV.js";
import "./chunk-U6T465MX.js";
import "./chunk-26IGLY6R.js";
import "./chunk-R7GQRDZ6.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
