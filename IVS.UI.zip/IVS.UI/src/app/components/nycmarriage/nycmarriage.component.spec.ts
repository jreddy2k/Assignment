import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NYCMarriageComponent } from './nycmarriage.component';

describe('NYCMarriageComponent', () => {
  let component: NYCMarriageComponent;
  let fixture: ComponentFixture<NYCMarriageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NYCMarriageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NYCMarriageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
