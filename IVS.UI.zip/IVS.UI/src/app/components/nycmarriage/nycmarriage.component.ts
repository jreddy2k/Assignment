import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatchService } from '../../services/match.service';
import { Marriage } from '../../models/Marriage';
@Component({
  selector: 'app-nycmarriage',
  templateUrl: './nycmarriage.component.html',
  styleUrl: './nycmarriage.component.css',
})
export class NYCMarriageComponent {
  
  marriageList: Marriage[] = [];//Add
  //Marriage
  constructor(
    private spinner: NgxSpinnerService,
    private matchService: MatchService
  ) {}

  ngOnInit(): void {}
  
  GetMarriage(
    caseNo: string,
    clientID: string,
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ) {
    this.spinner.show();
    this.matchService
      .GetMarriage(
        caseNo,
        clientID,
        histConnId,
        sessionId,
        posRoleId,
        centerId,
        groupId
      )
      .subscribe((result) => {
        this.marriageList = result;//Add
        this.spinner.hide();
      });
  }
  //GetMarriage(string caseNo, string clientID, int histConnId, int sessionId, string posRoleId, string centerId, int groupId)
}
