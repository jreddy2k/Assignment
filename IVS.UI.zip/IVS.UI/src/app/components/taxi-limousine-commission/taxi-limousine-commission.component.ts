import { Component } from '@angular/core';

@Component({
  selector: 'app-taxi-limousine-commission',
  templateUrl: './taxi-limousine-commission.component.html',
  styleUrl: './taxi-limousine-commission.component.css'
})
export class TaxiLimousineCommissionComponent {

}
