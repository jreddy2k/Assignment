import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxiLimousineCommissionComponent } from './taxi-limousine-commission.component';

describe('TaxiLimousineCommissionComponent', () => {
  let component: TaxiLimousineCommissionComponent;
  let fixture: ComponentFixture<TaxiLimousineCommissionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TaxiLimousineCommissionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TaxiLimousineCommissionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
