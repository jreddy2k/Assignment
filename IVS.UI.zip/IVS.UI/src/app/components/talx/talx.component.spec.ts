import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TALXComponent } from './talx.component';

describe('TALXComponent', () => {
  let component: TALXComponent;
  let fixture: ComponentFixture<TALXComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TALXComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TALXComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
