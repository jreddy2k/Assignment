import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatchService } from '../../services/match.service';
import { TALX } from '../../models/TALX';
import { Tab } from '../../models/Tab';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'app-talx',
  templateUrl: './talx.component.html',
  styleUrl: './talx.component.css',
})
export class TALXComponent {
  JobInfo: TALX[] = []; //Add
  jobiteminfo: TALX = new TALX(); //Add
  TALXTabInfo: Tab[] = [];
  //TALX
  tabname: string = '';
  tabssn: string = '';
  tabdob: string = '';

  constructor(
    private spinner: NgxSpinnerService,
    private matchService: MatchService,
    private commonService: CommonService
  ) {}

  ngOnInit(): void {
    //
    this.GetTabItems('00014212618E', 'TALX', 0, 2095181, '23', 'IVS');
    this.GetTALXInfo('759533', '564606','00014212618E', 0, 2095181, '23', 'IVS',1013);
    // //getTALXInfo/759533/564606/00014212618E/0/2095181/23/IVS/1013
  }

  GetTabItems(
    caseNo: string,
    screen: string,
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string
  ) {
    this.spinner.show();
    this.commonService
      .GetTabItems(caseNo, screen, histConnId, sessionId, posRoleId, centerId)
      .subscribe((result) => {
        this.TALXTabInfo = result; //Add
        this.spinner.hide();
      });
  }

  GetTALXInfo(
    resultID: string,
    clientID: string,
    caseNo: string,
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ) {
    this.spinner.show();
    this.matchService
      .GetTALXInfo(
        resultID,
        clientID,
        caseNo,
        histConnId,
        sessionId,
        posRoleId,
        centerId,
        groupId
      )
      .subscribe((result) => {
        this.JobInfo = result; //Add
        if (result != null && result.length > 0) this.jobiteminfo = result[0];
        else this.jobiteminfo = new TALX();
        this.spinner.hide();
      });
  }

  getclass(resultId: number): string {
    // Dummy implementation: return a class based on the resultId
    return resultId === 1 ? 'active' : '';
  }

  tabClick(
    resultId: number,
    clientId: number,
    path: string,
    name: string,
    ssn: string,
    dob: string
  ): void {
    
    console.log(`Tab clicked: ${name}`);
    this.tabname = name;
    this.tabssn = ssn;
    this.tabdob = dob;
    
  }

  getclass_subtab(index: number): string {
    // Dummy implementation: return a class based on the subtab index
    return index === 0 ? 'active' : '';
  }

  SubtabClick(index: number): void {
    // Dummy implementation: log the subtab click details
    console.log(`Subtab clicked: Job ${index + 1}`);
    // Add further logic as needed
  }

  close(): void {
    // Dummy implementation: log the close action
    console.log('Close button clicked');
    // Add further logic as needed
  }
}
