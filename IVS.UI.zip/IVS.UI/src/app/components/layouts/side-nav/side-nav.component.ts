import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatTableDataSource } from '@angular/material/table';
import { DynamicMenu } from '../../../models/DynamicMenu';
import { CommonService } from '../../../services/common.service';
import { Router } from '@angular/router';
import { SessionManagerService } from '../../../services/session-manager.service';
import { Login } from '../../../models/Login';
import { LoginService } from '../../../services/login.service';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrl: './side-nav.component.css'
})
export class SideNavComponent {
  dMenulist: DynamicMenu[] = [];
  dataSource: any = this.dMenulist;
  DisplayName:string="Sridhar Gangidi";
  EmailAddress:string ='gangidis@dss.nyc.gov';
  role!: string;
  roleoptions: any;
  menuitems: NavItem[] = [];
  strSearch:string = '';
  // searchBy:string =''
  searchValue!:string;
  searchBy:string='caseno';
  login: Login = new Login();
   _datetime:any = new Date();
  constructor(
    private spinner: NgxSpinnerService,
    private commonService: CommonService,
    private router:Router,
    private loginService: LoginService,
    private sessionService: SessionManagerService
  ) {
    this.login = this.sessionService.getItem('login');
    // console.log(this.login, 'sidenav');
    this.loginService.accessSubject$.subscribe(data => {
      this.login = data;
    });
  }
  ngOnInit(): void {
    // this.GetMenuItems('104',this.login.L_SESSION_ID,this.login.PERS_POS_ROLE,'00014201493F','23','IVS',1013,'0',0);
    // debugger;
        
    this.dMenulist = this.GetMenuItems();        
    this.dataSource = new MatTableDataSource<DynamicMenu>(this.dMenulist); 
  }
    
  getInitials(): string {
    var fullName = this.DisplayName.split(' ');
    var initials =
      (fullName?.shift()?.charAt(0) || '') + (fullName?.pop()?.charAt(0) || '');
    return initials.toUpperCase();
  }

  GetMenuItems( 
    ): DynamicMenu[] {
    return [
      {
        CODE_ID: 101,
        DESCRIPTION: "IVS Home",
        VALUE: null,
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: null,
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 103,
        DESCRIPTION: "Search Results",
        VALUE: "/search",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: null,
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 104,
        DESCRIPTION: "Match Summary",
        VALUE: "/matchSummary",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: null,
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 116,
        DESCRIPTION: "Match Details",
        VALUE: null,
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: null,
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 107,
        DESCRIPTION: "NYCHA Section 8",
        VALUE: "/nychaSection8",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M2",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 108,
        DESCRIPTION: "HPD Section 8",
        VALUE: "/hpd",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M8",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 113,
        DESCRIPTION: "NYC Marriage",
        VALUE: "/nycMarriage",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M1",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 110,
        DESCRIPTION: "NYC Vital Records",
        VALUE: "/nycVitalStats",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M9",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 106,
        DESCRIPTION: "TALX",
        VALUE: "/talx",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M4",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 114,
        DESCRIPTION: "NYC Employee",
        VALUE: "/nycEmployee",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M3",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 111,
        DESCRIPTION: "ACCIS - Childcare Provider Income",
        VALUE: "/accis",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M7",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 112,
        DESCRIPTION: "Taxi Limousine Commission",
        VALUE: "/taxiLimousineCommission",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M5",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 109,
        DESCRIPTION: "Child Support Income",
        VALUE: "/childSupportIncome",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M6",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 117,
        DESCRIPTION: "Child Support Expense",
        VALUE: "/childSupportExpense",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M10",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 118,
        DESCRIPTION: "DHS CARES",
        VALUE: "/dhsCares",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: "M11",
        HasSubMenu: false,
        HasParent: false
      },
      {
        CODE_ID: 105,
        DESCRIPTION: "Match Run History",
        VALUE: "/matchRunHistory",
        Enabled: false,
        DISPLAY: "Y",
        REF_CODE3: null,
        HasSubMenu: false,
        HasParent: false
      }
    ];
  }
  
  // GetMenuItems(
  //   screen: string,
  //   sessionId: number,
  //   roleId: number,
  //   caseNumber: string,
  //   posRoleId: string,
  //   centerId: string,
  //   groupId: number,
  //   histConnId: string,
  //   sourceId: number
  // ){
  //   this.spinner.show();
  //   this.commonService
  //     .GetMenuItems(
  //       screen,        
  //       sessionId,
  //       roleId,
  //       caseNumber,
  //       posRoleId,
  //       centerId,
  //       groupId,
  //       histConnId,
  //       sourceId
  //     )
  //     .subscribe((result) => {
        
  //       this.dMenulist = result;
        
  //       this.dataSource = new MatTableDataSource<DynamicMenu>(this.dMenulist);        
  //       this.spinner.hide();        
  //     });
  // }

  Home() {
    this.router.navigateByUrl('/')
  }

  onZoomChange(){
  }

  btnSearch() { 

    this.sessionService.setItem('searchBy', this.searchBy);
    this.sessionService.setItem('searchValue', this.searchValue);
    this.router.navigate(['/search'], { queryParams: { reload: new Date().getTime() } });
  
  }

  logout() {    
  }

  toggleSubMenu(menuItem: DynamicMenu): void {
    //menuItem.showSubItems = !menuItem.showSubItems;
   
    // this.menuitems.forEach((item) => {
    //   if (item !== menuItem) {
    //     item.showSubItems = false;
    //   }
    // });
  }
}
export class NavItem {
  MenuName!: string;
  MenuURL!: string;
  showSubItems!: boolean;
  SubItems!: NavItem[] | null;
}