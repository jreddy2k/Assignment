import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  CurrentDate:string;
  userName:string='Sridhar Gangidi';
  zoom(percentage: string) {
    (document.body.style as any).zoom = percentage;
  }
  
  constructor(){
    this.CurrentDate = new Date().toLocaleDateString();
    
  } 
  
  ngOnint():void{

  }
}
