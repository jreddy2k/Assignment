import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { LoginService } from '../../services/login.service';
import { SessionManagerService } from '../../services/session-manager.service';
import { Login } from '../../models/Login';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {
  searchValue!: string;
  searchBy: string = 'CASE_NO';
  login: Login = new Login();
  constructor(
    private spinner: NgxSpinnerService,
    private loginService: LoginService,
    private sessionService: SessionManagerService
  ) {
    this.login = this.sessionService.getItem('login');
  }

  ngOnInit(): void {}

  GetLoginInfo(sourceId: number) {
    this.spinner.show();
    this.loginService.GetLoginInfo(sourceId).subscribe((result) => {
      this.spinner.hide();
    });
  }

  btnclick() {
    // this.GetSearchDetails('SSN', '000000000', 2095020, '23', 'IVS');
  }
}
