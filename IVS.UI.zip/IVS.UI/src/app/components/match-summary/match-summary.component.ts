import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatchsummaryService } from '../../services/matchsummary.service';
import { CommonService } from '../../services/common.service';
import { MatchSummary } from '../../models/MatchSummary';
import {MatIconModule} from '@angular/material/icon'
import { SessionManagerService } from '../../services/session-manager.service';
import { Login } from '../../models/Login';
@Component({
  selector: 'app-match-summary',
  templateUrl: './match-summary.component.html',
  styleUrl: './match-summary.component.css',
})
export class MatchSummaryComponent {
  matchSummary:MatchSummary=new MatchSummary();
  login:Login=new Login();
  Case_Num:string = '';
  constructor(
    private spinner: NgxSpinnerService,
    private matchsummaryService: MatchsummaryService,
    private sessionManagerService: SessionManagerService
  ) {
    this.login = this.sessionManagerService.getItem('login');
    this.Case_Num = this.sessionManagerService.getItem('CASE_NO');
  }

  ngOnInit(): void {
    // this.spinner.show();
    this.GetMatchSummary('CASE_NO', this.Case_Num, this.login.L_SESSION_ID, this.login.PERS_POS_ROLE, this.login.PERS_CNTR_ID,1013);
    // getMatchSummary/CASE_NO/00013603353H/2095198/23/IVS/1013
    //https://localhost:44367/api/MatchSummary/GetMatchSummary?searchCriteria=CASE_NO&searchInfo=00011888422A&sessionId=2095105&posRoleId=23&centerId=IVS&groupId=1013
  }
  
  GetMatchSummary(
    searchCriteria: string,
    searchInfo: string,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ) {
    this.spinner.show();
    this.matchsummaryService
      .GetMatchSummary(
        searchCriteria,
        searchInfo,
        sessionId,
        posRoleId,
        centerId,
        groupId
      )
      .subscribe((result) => {        
        this.matchSummary = result;
        console.log(this.matchSummary);
        console.log(this.matchSummary.Header);
        console.log(this.matchSummary.Detail);
        this.spinner.hide();    
      });
  }
}
