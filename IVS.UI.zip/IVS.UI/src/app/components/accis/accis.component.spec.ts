import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ACCISComponent } from './accis.component';

describe('ACCISComponent', () => {
  let component: ACCISComponent;
  let fixture: ComponentFixture<ACCISComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ACCISComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ACCISComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
