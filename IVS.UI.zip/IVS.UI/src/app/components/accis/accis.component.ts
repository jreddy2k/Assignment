import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatchService } from '../../services/match.service';
import { ACCISChildcare } from '../../models/ACCISChildcare';

@Component({
  selector: 'app-accis',
  templateUrl: './accis.component.html',
  styleUrl: './accis.component.css'
})
export class ACCISComponent {
  accischildList: ACCISChildcare[] = [];//Add 
  constructor(
    private spinner: NgxSpinnerService,
    private matchService: MatchService
  ) {}

  ngOnInit(): void {}
  
  GetACCISChildcareInfo(
    resultID:string,
    clientID: string,     
    caseNo: string,       
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ) {
    this.spinner.show();
    this.matchService
      .GetACCISChildcareInfo(
        resultID,
        clientID,
        caseNo,        
        histConnId,
        sessionId,
        posRoleId,
        centerId,
        groupId
      )
      .subscribe((result) => {
        this.accischildList = result;//Add
        this.spinner.hide();
      });
  }
  //GetACCISChildcareInfo(string resultID, string clientID, string caseNo, int histConnId, int sessionId, string posRoleId, string centerId, int groupId)
}
