import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildSupportExpenseComponent } from './child-support-expense.component';

describe('ChildSupportExpenseComponent', () => {
  let component: ChildSupportExpenseComponent;
  let fixture: ComponentFixture<ChildSupportExpenseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChildSupportExpenseComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChildSupportExpenseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
