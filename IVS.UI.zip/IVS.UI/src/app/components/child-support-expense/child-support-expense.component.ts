import { Component } from '@angular/core';

@Component({
  selector: 'app-child-support-expense',
  templateUrl: './child-support-expense.component.html',
  styleUrl: './child-support-expense.component.css'
})
export class ChildSupportExpenseComponent {

}
