import { Component } from '@angular/core';
import { VitalStats } from '../../models/VitalStats';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatchService } from '../../services/match.service';

@Component({
  selector: 'app-nycvital-stats',
  templateUrl: './nycvital-stats.component.html',
  styleUrl: './nycvital-stats.component.css'
})
export class NYCVitalStatsComponent {
  vitalstatsList: VitalStats[] = [];//Add
  //Marriage
  constructor(
    private spinner: NgxSpinnerService,
    private matchService: MatchService
  ) {}

  ngOnInit(): void {}
  
  GetNYCVitalStats(    
    caseNo: string,
    clientID: string,    
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ) {
    this.spinner.show();
    this.matchService
      .GetNYCVitalStats(
        caseNo,
        clientID,
        histConnId,
        sessionId,
        posRoleId,
        centerId,
        groupId
      )
      .subscribe((result) => {
        this.vitalstatsList = result;//Add
        this.spinner.hide();
      });
  }
}
