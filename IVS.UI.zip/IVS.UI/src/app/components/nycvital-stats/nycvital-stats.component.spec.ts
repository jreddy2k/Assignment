import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NYCVitalStatsComponent } from './nycvital-stats.component';

describe('NYCVitalStatsComponent', () => {
  let component: NYCVitalStatsComponent;
  let fixture: ComponentFixture<NYCVitalStatsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NYCVitalStatsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NYCVitalStatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
