import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NYCHASection8Component } from './nychasection8.component';

describe('NYCHASection8Component', () => {
  let component: NYCHASection8Component;
  let fixture: ComponentFixture<NYCHASection8Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NYCHASection8Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NYCHASection8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
