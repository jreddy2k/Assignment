import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatchService } from '../../services/match.service';
import { NYCHASec8 } from '../../models/NYCHASec8';

@Component({
  selector: 'app-nychasection8',
  templateUrl: './nychasection8.component.html',
  styleUrl: './nychasection8.component.css'
})
export class NYCHASection8Component {

  caseName: string = 'Sample Case Name';
  caseNo: string = '123456';
  loading: boolean = false;
  tabname: string = 'John Doe';
  tabssn: string = '123-45-6789';
  tabdob: string = '01/01/1980';

  NYCHASection8TabInfo: any[] = [
    { ResultId: 1, ClientId: 'A1', Path: '/path1', Name: 'Tab 1', SSN: '123-45-6789', DOB: '01/01/1980' },
    { ResultId: 2, ClientId: 'A2', Path: '/path2', Name: 'Tab 2', SSN: '987-65-4321', DOB: '02/02/1990' },
    { ResultId: 3, ClientId: 'A3', Path: '/path3', Name: 'Tab 3', SSN: '111-22-3333', DOB: '03/03/2000' }
  ];

  NYCHASection8Info: any = {
    Address: '123 Main St, New York, NY 10001',
    NYCHALastRecertDate: '12/21',
    TenantShareSec8Rent: '$500',
    NYCHAShareSec8Rent: '$1500',
    RequestDate: '06/25/2024',
    ResultDate: '06/24/2024'
  };
  getclass(ResultId: number): string {
    // Implement your logic to get the class based on ResultId
    return ResultId === 1 ? 'active' : '';
  }

  tabClick(ResultId: number, ClientId: string, Path: string, Name: string, SSN: string, DOB: string): void {
    this.tabname = Name;
    this.tabssn = SSN;
    this.tabdob = DOB;
    // Additional logic to handle tab click
  }


  nychaSec8List: NYCHASec8[] = [];//Add 
  constructor(
    private spinner: NgxSpinnerService,
    private matchService: MatchService
  ) {}

  ngOnInit(): void {}
  
  GetNYCHASection8Info(
    resultID:string,
    clientID: string,     
    caseNo: string,       
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ) {
    this.spinner.show();
    this.matchService
      .GetNYCHASection8Info(
        resultID,
        clientID,
        caseNo,        
        histConnId,
        sessionId,
        posRoleId,
        centerId,
        groupId
      )
      .subscribe((result) => {
        this.nychaSec8List = result;//Add
        this.spinner.hide();
      });
  }
}
