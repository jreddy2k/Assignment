import { Component } from '@angular/core';

@Component({
  selector: 'app-hpd',
  templateUrl: './hpd.component.html',
  styleUrl: './hpd.component.css'
})
export class HPDComponent {

}
