import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HPDComponent } from './hpd.component';

describe('HPDComponent', () => {
  let component: HPDComponent;
  let fixture: ComponentFixture<HPDComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HPDComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HPDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
