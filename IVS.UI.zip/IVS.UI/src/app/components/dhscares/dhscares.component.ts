import { Component } from '@angular/core';

@Component({
  selector: 'app-dhscares',
  templateUrl: './dhscares.component.html',
  styleUrl: './dhscares.component.css'
})
export class DHSCaresComponent {

}
