import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DHSCaresComponent } from './dhscares.component';

describe('DHSCaresComponent', () => {
  let component: DHSCaresComponent;
  let fixture: ComponentFixture<DHSCaresComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DHSCaresComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DHSCaresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
