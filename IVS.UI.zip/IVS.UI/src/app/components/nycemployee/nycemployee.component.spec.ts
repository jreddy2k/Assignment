import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NYCEmployeeComponent } from './nycemployee.component';

describe('NYCEmployeeComponent', () => {
  let component: NYCEmployeeComponent;
  let fixture: ComponentFixture<NYCEmployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NYCEmployeeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NYCEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
