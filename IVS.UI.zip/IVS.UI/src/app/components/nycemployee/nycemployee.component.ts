import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatchService } from '../../services/match.service';
import { NYCEmployee } from '../../models/NYCEmployee';

@Component({
  selector: 'app-nycemployee',
  templateUrl: './nycemployee.component.html',
  styleUrl: './nycemployee.component.css'
})
export class NYCEmployeeComponent {
  nycEmployeeList: NYCEmployee[] = [];//Add 
  
  constructor(
    private spinner: NgxSpinnerService,
    private matchService: MatchService
  ) {}

  ngOnInit(): void {}

  tabClick(){
    
  }
  
  GetNYCEmployeeInfo(
    resultID:string,
    clientID: string,     
    caseNo: string,       
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ) {
    this.spinner.show();
    this.matchService
      .GetNYCEmployeeInfo(
        resultID,
        clientID,
        caseNo,        
        histConnId,
        sessionId,
        posRoleId,
        centerId,
        groupId
      )
      .subscribe((result) => {
        this.nycEmployeeList = result;//Add
        this.spinner.hide();
      });
  }
}
