import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MatchRunHistoryComponent } from './match-run-history.component';

describe('MatchRunHistoryComponent', () => {
  let component: MatchRunHistoryComponent;
  let fixture: ComponentFixture<MatchRunHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MatchRunHistoryComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MatchRunHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
