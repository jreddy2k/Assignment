import { Component } from '@angular/core';

@Component({
  selector: 'app-match-run-history',
  templateUrl: './match-run-history.component.html',
  styleUrl: './match-run-history.component.css'
})
export class MatchRunHistoryComponent {

}
