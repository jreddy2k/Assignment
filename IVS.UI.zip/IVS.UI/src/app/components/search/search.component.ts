import { Component, ViewChild } from '@angular/core';
import { Search } from '../../models/Search';
import { SearchService } from '../../services/search.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Login } from '../../models/Login';
import { LoginService } from '../../services/login.service';
import { SessionManagerService } from '../../services/session-manager.service';
import { Router } from '@angular/router';
//import { FormControl } from '@angular/forms';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrl: './search.component.css',
})
export class SearchComponent {
  searchlist: Search[] = [];
  searchValue: string = '000000000';  
 // searchControl!: FormControl;
  searchBy: string = 'SSN';
  displayedColumns: string[] = [
    'CASE_NO',
    'CASE_TYPE',
    'CASE_NAME',
    'LAST_MODIFIED_ON',
  ];
  zoomLevels: string[] = ['90%', '100%', '110%', '125%'];
  zoom(multiplier: string) {
    (document.body.style as any).zoom = multiplier;
  }
  
  dataSource: any = this.searchlist;
  @ViewChild(MatSort, { static: true })
  sort!: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  login: Login = new Login();  
  constructor(
    private spinner: NgxSpinnerService,
    private searchService: SearchService,
    private loginService: LoginService,
    private sessionService: SessionManagerService,
    private router: Router
  ) {
    // this.login = this.sessionService.getItem('login');
     if (
      typeof this.searchBy === 'object' &&
      Object.keys(this.searchBy).length === 0
    ){
      this.searchBy = this.sessionService.getItem('searchBy');
      this.searchValue = this.sessionService.getItem('searchValue');
    }
   
    this.loginService.accessSubject$.subscribe((data) => {
      this.login = data;
      console.log(this.login, 'searchsubject');
      console.log(this.searchBy, 'searchby');
      
    });
  }
  
  ngOnInit(): void {
    // if (
    //   typeof this.searchBy === 'object' &&
    //   Object.keys(this.searchBy).length === 0
    // )
    //   this.GetSearchDetails(
    //     'SSN',
    //     '000000000',
    //     this.login.L_SESSION_ID,
    //     this.login.PERS_POS_ROLE,
    //     this.login.PERS_CNTR_ID
    //   );
    // else {
    //   this.GetSearchDetails(
    //     this.searchBy,
    //     this.searchValue,
    //     this.login.L_SESSION_ID,
    //     this.login.PERS_POS_ROLE,
    //     this.login.PERS_CNTR_ID
    //   );
    // }
   // this.searchControl = new FormControl('');
  }
 

  // onSSNInput() {
  //   if (this.searchBy === 'SSN') {
  //     let currentValue = this.searchControl.value.replace(/\D/g, ''); // Remove non-digits
  //     if (currentValue.length > 9) {
  //       currentValue = currentValue.substring(0, 9); // Limit to 9 digits
  //     }

  //     // Apply formatting
  //     const part1 = currentValue.substring(0, 3);
  //     const part2 = currentValue.substring(3, 5);
  //     const part3 = currentValue.substring(5, 9);

  //     this.searchControl.setValue(`${part1}${part2 ? '-' : ''}${part2}${part3 ? '-' : ''}${part3}`, { emitEvent: false });
  //   }
  // }

  btnSearch() {
    // console.log('search');
    // let searchValue = this.searchControl.value;
    // if (this.searchBy === 'SSN') {
    //   if (!this.isValidSSN(searchValue)) {
    //     alert('Invalid SSN format');
    //     return;
    //   }
    //   searchValue = this.stripSSNDashes(searchValue);
    this.GetSearchDetails(this.searchBy, this.searchValue, this.login.L_SESSION_ID, this.login.PERS_POS_ROLE, this.login.PERS_CNTR_ID);
    //this.GetSearchDetails(this.searchBy, this.searchValue, this.login.L_SESSION_ID, '23', 'IVS');
  }
//}
// isValidSSN(value: string): boolean {
//   const ssnPattern = /^\d{3}-\d{2}-\d{4}$/;
//   return ssnPattern.test(value);
// }
//   stripSSNDashes(value: string): string {
//     return value.replace(/-/g, '');
//   }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  loadDetails(CASE_NO: string) {
    this.sessionService.setItem('CASE_NO', CASE_NO);
    this.router.navigate(['/matchsummary']);
  }

  GetSearchDetails(
    searchCriteria: string,
    searchInfo: string,
    sessionId: number,
    posRoleId: string,
    centerId: string
  ) {
    this.spinner.show();
    this.searchService
      .GetSearchDetails(
        searchCriteria,
        searchInfo,
        sessionId,
        posRoleId,
        centerId
      )
      .subscribe((result) => {
        this.searchlist = result;
        this.dataSource = new MatTableDataSource<Search>(this.searchlist);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.spinner.hide();
      });
  }
}
