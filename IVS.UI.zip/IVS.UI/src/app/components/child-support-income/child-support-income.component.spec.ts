import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildSupportIncomeComponent } from './child-support-income.component';

describe('ChildSupportIncomeComponent', () => {
  let component: ChildSupportIncomeComponent;
  let fixture: ComponentFixture<ChildSupportIncomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChildSupportIncomeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChildSupportIncomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
