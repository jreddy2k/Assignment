// import { Component } from '@angular/core';
// import { ChildSupportIncome } from '../../models/ChildSupportIncome';
// import { NgxSpinnerService } from 'ngx-spinner';
// import { MatchService } from '../../services/match.service';
// import { Tab } from '../../models/Tab';
// import { CommonService } from '../../services/common.service';
// @Component({
//   selector: 'app-child-support-income',
//   templateUrl: './child-support-income.component.html',
//   styleUrl: './child-support-income.component.css'
// })
// export class ChildSupportIncomeComponent {
//   //chlsuppincomeList: ChildSupportIncome[] = [];//Add 
//   JobInfo: ChildSupportIncome[] = []; 
//   ChildSupportTabInfo:Tab[] = [];
//   ChildSupportInfo: ChildSupportIncome = new ChildSupportIncome();
//   tabname: string = '';
//   tabssn: string = '';
//   tabdob: string = '';
//   constructor(
//     private spinner: NgxSpinnerService,
//     private matchService: MatchService,
//     private commonService: CommonService
//   ) {}

//   ngOnInit(): void {

//   }
  
//   GetChildSupportIncome(
//     resultID:string,
//     clientID: string,     
//     caseNo: string,       
//     histConnId: number,
//     sessionId: number,
//     posRoleId: string,
//     centerId: string,
//     groupId: number
//   ) {
//     this.spinner.show();
//     this.matchService
//       .GetChildSupportIncome(
//         resultID,
//         clientID,
//         caseNo,        
//         histConnId,
//         sessionId,
//         posRoleId,
//         centerId,
//         groupId
//       )
//       .subscribe((result) => {
//         this.chlsuppincomeList = result;//Add
//         this.spinner.hide();
//       });
//   }
// }
