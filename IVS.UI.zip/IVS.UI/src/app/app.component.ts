import { Component } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { LoginService } from './services/login.service';
import { Login } from './models/Login';
import { SessionManagerService } from './services/session-manager.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'IVS.UI';
  sourceId: number = 0;
  login: Login = new Login();
  constructor(
    private spinner: NgxSpinnerService,
    private loginService: LoginService,
    private sessionService: SessionManagerService
  ) {}

  ngOnInit(): void {
    // this.spinner.show();
    if (this.sourceId == 0) {
      this.loginService.GetLoginInfo(this.sourceId).subscribe((result) => {
        this.login = result;
        this.loginService.accessSubject$.next(this.login);
        this.sessionService.setItem('login', result);
        // console.log(this.sessionService.getItem('login'));
        this.spinner.hide();
      });
    }
  }
}
