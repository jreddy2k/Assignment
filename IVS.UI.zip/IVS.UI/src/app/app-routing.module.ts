import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { MatchSummaryComponent } from './components/match-summary/match-summary.component';
import { SearchComponent } from './components/search/search.component';
import { HPDComponent } from './components/hpd/hpd.component';
import { NYCMarriageComponent } from './components/nycmarriage/nycmarriage.component';
import { SideNavComponent } from './components/layouts/side-nav/side-nav.component';
import { LayoutComponent } from './components/layouts/layout/layout.component';
import { NYCHASection8Component } from './components/nychasection8/nychasection8.component';
import { NYCEmployeeComponent } from './components/nycemployee/nycemployee.component';
import { TALXComponent } from './components/talx/talx.component';
import { HeaderComponent } from './components/layouts/header/header.component';



const routes: Routes = [
  { path: '', redirectTo: 'search', pathMatch: 'full' },
  { path: '', 
    component: HeaderComponent,
    children:[
      { path: 'home', component: HomeComponent },
      { path: 'search', component: SearchComponent },
    ]
    },
    {
    path: '', 
    component: HeaderComponent,
    children:[
      { path: 'matchsummary', component: MatchSummaryComponent },
      { path: 'hpd', component: HPDComponent },
      { path: 'nycmarriage', component: NYCMarriageComponent },
      { path: 'sidenav', component: SideNavComponent },
      { path: 'applayout', component: LayoutComponent },
      {path:'nychasection8', component:NYCHASection8Component},
      {path: 'nycemployee', component: NYCEmployeeComponent },
      {path:'talx',component:TALXComponent}
    ]
    },

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload' })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
