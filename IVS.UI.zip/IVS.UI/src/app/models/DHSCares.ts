export class DHSCares {
    resultID: number=0;
    requestDate: string='';
    resultDate: string='';
    firstName: string='';
    lastName: string='';
    dob: string='';
    ssn: string='';
    spokenLanguage: string='';
    paCaseNumber: string='';
    caresCaseNumber: string='';
    caresID: string='';
    composition: string='';
    shelterAgency: string='';
    shelterID: string='';
    shelterCode: string='';
    shelterName: string='';
    shelterAddress: string='';
    shelterPhone: string='';
    wmsShelterTypeCode: string='';
    lastCheckInDate: string='';
    lastCheckOutDate: string='';

    householdMembersList: CaresHouseholdMember[] = [];
}
export class CaresHouseholdMember {
    firstName: string='';
    lastName: string='';
    dob: string='';
    ssn: string='';
    relationshipType: string='';
    caresID: string='';
}
export class StreetSmart {
    requestDate: string='';
    resultDate: string='';
    streetSmartID: string='';
    firstName: string='';
    lastName: string='';
    dob: string='';
    ssn: string='';
    lastEngagementDate: string='';
    shelterName: string='';
    placementDate: string='';
    placementExitDate: string='';
    placementDescription: string='';
}
