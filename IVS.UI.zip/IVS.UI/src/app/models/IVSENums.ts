export class IVSEnums {
    static Screen = {
      NYC_VITAL_STATS: 110,
      NYC_MARRIAGE: 113,
      NYCHA_SECTION_8: 107,
      NYC_EMPLOYEE: 114,
      TALX: 106,
      TLC: 112,
      CHILD_SUPPORT_INCOME: 109,
      ACCIS: 111,
      HPD: 108,
      SEARCH: 103,
      MATCH_SUMMARY: 104,
      MATCH_RUN_HISTORY: 105,
      MATCH_DETAILS: 116,
      HOME: 101,
      CHILD_SUPPORT_EXPENSE: 117,
      DHS_CARES: 118
    } as const;
  
    static MatchCode = {
      NYC_MARRIAGE: 1,
      NYCHA_SECTION_8: 2,
      NYC_EMPLOYEE: 3,
      TALX: 4,
      TLC: 5,
      CHILD_SUPPORT_INCOME: 6,
      ACCIS: 7,
      HPD: 8,
      NYC_VITAL_STATS: 9,
      CHILD_SUPPORT_EXPENSE: 10,
      DHS_CARES: 11
    } as const;
  
    static ExceptionType = {
      GENERAL: 6,
      CONCURRENCY: 7,
      LOGIN_FAILED: 8,
      USER_NOT_FOUND: 9,
      DB_CONNECTIVITY: 10,
      SESSION_EXPIRED: 30,
      CENTER_TITLE_MISMATCH: undefined
    } as const;
  }
  