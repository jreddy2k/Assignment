export class MonthlyIncome {
    incomeDate!: Date;
    monthDate: string='';
    amount: string='';
}


export class NYCEmployee {
    authenticationValue: string='';
    agencyName: string='';
    resultID: number=0;
    requestDate: string='';
    resultDate: string='';
    leaveStatus: string='';
    leaveStatusDate: string='';
    basePay: string='';
    payPeriod: string='';
    cityHireDate: string='';
    incomeList: MonthlyIncome[] = [];
}
