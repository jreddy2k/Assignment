export class Marriage {
    authenticationValue: string='';
    resultID: number=0;
    requestDate: string='';
    resultDate: string='';
    marriageRecordsNo: number=0;
    spouse1Label: string='';
    spouse1Name: string='';
    spouse1FontColor: string='';
    spouse1Aka: string='';
    spouse1SSN: string='';
    spouse2Label: string='';
    spouse2Name: string='';
    spouse2FontColor: string='';
    spouse2Aka: string='';
    spouse2SSN: string='';
    ceremonyDate: string='';
    licenseNumber: string='';
}
