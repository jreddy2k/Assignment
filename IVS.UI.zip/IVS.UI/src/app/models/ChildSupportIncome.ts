export interface ChildSupport {
    authenticationValue?: string;
    resultId: number;
    requestDate?: string;
    resultDate?: string;
    csmsNumber?: string;
    custoParent?: string;
    ncustoParent?: string;
    effectiveDate?: string;
    obligationAmount?: string;
    incomeList: ChildSupportIncome[];
    childrenList: ChildSupportChildren[];
}
export interface ChildSupportIncome {
    paymentDate?: string;
    amount?: string;
    source?: string;
}
export interface ChildSupportChildren {
    childName?: string;
    childDob?: string;
    childSsn?: string;
}