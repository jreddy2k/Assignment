export class Tab {
    ResultId: number=0;    
    ClientId: number=0;
    Name: string='';
    DOB: string='';
    SSN: string='';
    Path: string='';
}