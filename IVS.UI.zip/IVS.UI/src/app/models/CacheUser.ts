export class CacheUser {
    roleID: number=0;
    groupID: number=0;
    sessionID: number=0;
    posRoleID: string='';
    centerID: string='';
}
