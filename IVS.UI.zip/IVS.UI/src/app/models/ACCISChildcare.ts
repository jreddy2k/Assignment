export class ACCISChildcare {
    authenticationValue: string='';
    resultID: number=0;
    versionID: number=0;
    requestDate: string='';
    resultDate: string='';
    providerType: string='';
    providerSSN: string='';
    providerStatus: string='';
    providerNo: string='';
    providerStatusDate: string='';
    caseMember: string='';
    resStreetAddress: string='';
    resCityStateZip: string='';
    childrenEnrolledNo: string='';
    incomeListV1!: ACCISChildcareIncome_V1[];
    incomeListV2!: ACCISChildcareIncome_V2[];
}

export class ACCISChildcareIncome_V1 {
    checkDate: string='';
    grossPay: string='';
    serviceMonth: string='';
    totalFee: string='';
    totalAmount: string='';
}

export class ACCISChildcareIncome_V2 {
    serviceMonth: string='';
    paymentMonth: string='';
    paymentAmount: string='';
    feeAmount: string='';
    grossAmount: string='';
    childrenList!: ACCISChildcareChildren[];
}

export class ACCISChildcareChildren {
    childName: string='';
    // You can uncomment and add more properties if needed
}
