export class NYCHASec8 {
    authenticationValue: string='';
    resultID: number=0;
    requestDate: string='';
    resultDate: string='';
    tenantShareSec8Rent: string='';
    nychaShareSec8Rent: string='';
    nychaRentAmount: string='';
    nychaLastRecertDate: string='';
    address: string='';
}
