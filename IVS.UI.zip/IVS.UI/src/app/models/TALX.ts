export class TALX {
    AUTHENTICATION_VALUE?: string;
    RESULT_ID: number = 0;
    IVS_REQUEST_DATE?: string;
    RESULT_DATE?: string;
    EMPLOYEE_STATUS_MESSAGE?: string;
  
    EMPLOYEE_ADDRESS1?: string;
    EMPLOYEE_ADDRESS2?: string;
    EMPLOYEE_CITY?: string;
    EMPLOYEE_STATE?: string;
    EMPLOYEE_POSTAL_CODE?: string;
  
    EMPLOYER_NAME?: string;
    EMPLOYER_CODE?: string;
  
    EMPLOYER_ADDRESS1?: string;
    EMPLOYER_ADDRESS2?: string;
    EMPLOYER_CITY?: string;
    EMPLOYER_STATE?: string;
    EMPLOYER_POSTAL_CODE?: string;
    EMPLOYER_ISO_COUNTRY_CODE?: string;
  
    EMPLOYEE_INFO_EFFECTIVE_DATE?: string;
    EMPLOYEE_MOST_RECENT_HIRE_DATE?: string;
    EMPLOYEE_TOTAL_LENGTH_OF_SVC?: string;
    EMPLOYEE_TERMINATION_DATE?: string;
    EMPLOYEE_TERMINATION_MESSAGE?: string;
    PAY_FREQUENCY_MESSAGE?: string;
    AVERAGE_HOURS_WORKED_PER_PP?: string;
    RATE_OF_PAY?: string;
    PensionIncome?: string;
    AdditionalIncome?: string;
    WorkersCompBenefit?: string;
    CarrierName?: string;
    AwardDate?: string;
    WorkersCompCompensation?: string;
    ClaimNumber?: string;
    ClaimPending?: string;
    LocationCode?: string;
    SiteCode?: string;
    DepartmentCode?: string;
    MedicalInsurance?: string;
    EmployeeEnrolled?: string;
    EligibleDate?: string;
    CoverageStartDate?: string;
    CoverageEndDate?: string;
    DependentAvailable?: string;
    NoOfDependents?: string;
    DependentCost?: string;
    EmployeeAddress?:string;
    EmployerAddress?:string;
    private payList: TALXPay[] = [];
  
    get PayList(): TALXPay[] {
      return this.payList;
    }
  }
  
  export class TALXPay {
    PAY_PERIOD_BEGIN_DATE?: string;
    PAY_PERIOD_END_DATE?: string;
    PAY_DATE?: string;
    PERIOD_HOURS_WORKED?: string;
    PERIOD_GROSS_EARNINGS?: string;
    PERIOD_YTD_GROSS_EARNINGS?: string;
  }
  