export class DynamicMenu {
    CODE_ID: number = 0;
    DESCRIPTION: string='';
    VALUE!: string | null;   
    Enabled!: boolean;    
    DISPLAY: string = '';    
    REF_CODE3!: string| null;;
    HasSubMenu!: boolean;
    HasParent!: boolean;
}
