export class Login {
    L_SESSION_ID: number=0;
    PERS_ASSOCIATED_LAN_ID?: string='';
    MachineName?: string='';
    PERS_FIRST_NAME?: string='';
    CurrentDateTime?: string='';
    PERS_IVS_ROLE: number=0;
    PERS_IVS_GROUP: number=0;
    PERS_POS_ROLE: string='';
    PERS_CNTR_ID: string='';
    DESCRIPTION?: string='';
    REF_CODE1?: boolean;
    DisplaySearchBar?: boolean;
}
