export class VitalStats {
    individualName: string='';
    statusCode: string='';
    dob: string='';
}


export class NYCVitalStats {
    authenticationValue: string='';
    resultID: number=0;
    requestDate: string='';
    resultDate: string='';
    noOfRecords: number=0;
    vitalStatsList: VitalStats[] = [];
}
