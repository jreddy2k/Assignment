export class MatchHistory {
    histConnId: number=0;
    orderBy: string='';
    caseNo: string='';
    caseType: string='';
    caseName: string='';
    requestDateTime: string='';
    requestedBy: string='';
    event: string='';
}
