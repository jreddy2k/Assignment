
export class Search {
    CASE_NO: string='';    
    CASE_TYPE: string='';
    CASE_NAME: string='';
    LAST_MODIFIED_ON: string='';
    
}
