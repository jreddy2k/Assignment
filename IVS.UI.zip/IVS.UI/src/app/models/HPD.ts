export class HPD {
    authenticationValue: string='';
    resultID: number=0;
    resultDate: string='';
    requestDate: string='';
    processDate: string='';
    address: string='';
    borough: string='';
    zip: string='';
    aptNo: string='';
    tenantRent: string='';
    subsidy: string='';
    totalRent: string='';
}
