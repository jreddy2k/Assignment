export class HeaderItem {
    FIRST_NAME?: string='';
    LAST_NAME?: string='';
    DOB?: string='';
    SSN?: string='';
    IVS_REQUEST_DATE?: string='';
  }
  
  export class Header extends Array<HeaderItem> {
  }
  
  export class DetailMatchItem {
    _STATUS: number = 0; // use to get the status id
    _RESULT_ID: number = 0;
    CLIENT_ID?: string='';
    _STATUSIMAGE?: string='';
    _RESULT_DATE?: string='';
    ResultDateLabel?: string='';
    IVS_REQUEST_DATE?: string='';
    ClickAllowed: boolean = false;
  }
  
  export class DetailRow {
    MatchName?: string='';
    MatchCode?: string='';
    ItemList: DetailMatchItem[];
  
    constructor() {
      this.ItemList = [];
    }
  }
  
  export class Detail extends Array<DetailRow> {
  }
  
  export class MatchSummary {
    CASENAME?: string='';
    CASENO?: string='';
    CLIENT_ID?: string='';
    IVS_REQUEST_DATE?: string='';
    ExecTime?: string='';
    ShowExecTimes: boolean;
    Header: Header;
    Detail: Detail;
  
    constructor() {
      this.ShowExecTimes = false;
      this.Header = new Header();
      this.Detail = new Detail();
    }
  }
  