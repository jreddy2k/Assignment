export class ChildSupportExpense {
    authenticationValue: string='';
    resultID: number=0;
    requestDate: string='';
    resultDate: string='';
    csmsNumber: string='';
    custoParent: string='';
    nCustoParent: string='';
    effectiveDate: string='';
    obligationAmount: string='';
    expenseList!: ChildSupportExpenseDetails[];
    childrenList!: ChildSupportExpenseChildren[];
}

export class ChildSupportExpenseDetails {
    paymentDate: string='';
    amount: string='';
    source: string='';
}

export class ChildSupportExpenseChildren {
    childName: string='';
    childDOB: string='';
    childSSN: string='';
}
