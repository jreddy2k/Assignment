import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Login } from '../models/Login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  public accessSubject$ = new Subject<Login>();
  private apiUrl = 'https://localhost:44367/api'; // Replace with your API endpoint
  httpOption = {
    header: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
    rejectUnauthorized: false,
  };
  constructor(private http: HttpClient) {}

  //Login GetLoginInfo(int sourceId)
  GetLoginInfo(
   
    sourceId: number,
    
  ): Observable<Login> {
    return this.http.get<
    Login
    >(`${this.apiUrl}/Login/GetLoginInfo?sourceId=${sourceId}`);
  }
}
