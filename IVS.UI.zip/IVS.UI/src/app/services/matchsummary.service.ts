import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatchSummary } from '../models/MatchSummary';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MatchsummaryService {

  private apiUrl = 'https://localhost:44367/api'; // Replace with your API endpoint
  httpOption = {
    header: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
    rejectUnauthorized: false,
  };
  constructor(private http: HttpClient) {}
  GetMatchSummary(
    searchCriteria: string,
    searchInfo: string,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ): Observable<MatchSummary> {
    return this.http.get<
    MatchSummary
    >(`${this.apiUrl}/MatchSummary/GetMatchSummary?searchCriteria=${searchCriteria}&searchInfo=
    ${searchInfo}&sessionId=${sessionId}&posRoleId=${posRoleId}&centerId=${centerId}&&groupId=${groupId}`);
  }
  //GetMatchSummary(string searchCriteria, string searchInfo, int sessionId, string posRoleId, string centerId, int groupId)
}
