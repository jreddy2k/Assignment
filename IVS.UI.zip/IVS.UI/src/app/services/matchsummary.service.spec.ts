import { TestBed } from '@angular/core/testing';

import { MatchsummaryService } from './matchsummary.service';

describe('MatchsummaryService', () => {
  let service: MatchsummaryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MatchsummaryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
