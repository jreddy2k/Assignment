import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Tab } from '../models/Tab';
import { Observable } from 'rxjs';
import { DynamicMenu } from '../models/DynamicMenu';

@Injectable({
  providedIn: 'root',
})
export class CommonService {
  private apiUrl = 'https://localhost:44367/api'; // Replace with your API endpoint
  httpOption = {
    header: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
    rejectUnauthorized: false,
  };
  constructor(private http: HttpClient) {}
  GetMenuItems(
    screen: string,
    sessionId: number,
    roleId: number,
    caseNumber: string,
    posRoleId: string,
    centerId: string,
    groupId: number,
    histConnId: string,
    sourceId: number
  ): Observable<DynamicMenu[]> {
    return this.http.get<
      DynamicMenu[]
    >(`${this.apiUrl}/Common/GetMenuItems?screen=${screen}&sessionId=${sessionId}&roleId=${roleId}&caseNumber=${caseNumber}&posRoleId=${posRoleId}&centerId=${centerId}&groupId=${groupId}&histConnId=${histConnId}&sourceId=${sourceId}`);
  }
  //GetMenuItems(string screen, int sessionId, int roleId, string caseNumber, string posRoleId, string centerId, int groupId, string histConnId, int sourceId)
  GetTabItems(
    caseNumber: string,
    screen: string,
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string
  ): Observable<Tab[]> {
    return this.http.get<
      Tab[]
    >(`${this.apiUrl}/Common/GetTabItems?caseNo=${caseNumber}&screen=${screen}&histConnId=${histConnId}&sessionId=${sessionId}&posRoleId=${posRoleId}&centerId=${centerId}`);
  }
  IsUserAllowed(
    matchCode: string,
    screenId: number,
    sessionId: number,
    roleId: number
  ): Observable<string> {
    return this.http.get<string>(
      `${this.apiUrl}/Common/IsUserAllowed?matchCode=${matchCode}&screenId=${screenId}&sessionId=${sessionId}&roleId=${roleId}`
    );
  }
  //GetTabItems(string caseNo, string screen, int histConnId, int sessionId, string posRoleId, string centerId)
  //GetMenuItems(string screen, int sessionId, int roleId, string caseNumber, string posRoleId, string centerId, int groupId, string histConnId, int sourceId)
  //IsUserAllowed(string matchCode, int screenId, int sessionId, int roleId)
}
