import { Injectable } from '@angular/core';
import { Search } from '../models/Search';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SearchService {
  private apiUrl = 'https://localhost:44367/api'; // Replace with your API endpoint
  httpOption = {
    header: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
    rejectUnauthorized: false,
  };
  constructor(private http: HttpClient) {}

  GetSearchDetails(
    searchCriteria: string,
    searchInfo: string,
    sessionId: number,
    posRoleId: string,
    centerId: string
  ): Observable<Search[]> {
    return this.http.get<
      Search[]
    >(`${this.apiUrl}/search/GetSearchDetails?searchCriteria=${searchCriteria}&searchInfo=
    ${searchInfo}&sessionId=${sessionId}&posRoleId=${posRoleId}&centerId=${centerId}`);
  }
}
