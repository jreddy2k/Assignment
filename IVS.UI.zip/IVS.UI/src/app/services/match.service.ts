import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Marriage } from '../models/Marriage';
import { Observable } from 'rxjs';
import { TALX } from '../models/TALX';
import { VitalStats } from '../models/VitalStats';
import { ChildSupportIncome } from '../models/ChildSupportIncome';
import { NYCEmployee } from '../models/NYCEmployee';
import { NYCHASec8 } from '../models/NYCHASec8';
import { ACCISChildcare } from '../models/ACCISChildcare';

@Injectable({
  providedIn: 'root',
})
export class MatchService {
  private apiUrl = 'https://localhost:44367/api'; // Replace with your API endpoint
  httpOption = {
    header: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
    rejectUnauthorized: false,
  };

  constructor(private http: HttpClient) {}

  GetMarriage(
    caseNo: string,
    clientID: string,
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ): Observable<Marriage[]> {
    return this.http.get<
      Marriage[]
    >(`${this.apiUrl}/Match/GetMarriage?caseNo=${caseNo}&clientID=
    ${clientID}&histConnId=${histConnId}&sessionId=${sessionId}&posRoleId=${posRoleId}&centerId=${centerId}&groupId=${groupId}`);
  }
  // GetMarriage(string caseNo, string clientID, int histConnId, int sessionId, string posRoleId, string centerId, int groupId)
  GetTALXInfo(
    resultID: string,
    clientID: string,
    caseNo: string,
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ): Observable<TALX[]> {
    return this.http.get<
    TALX[]
    >(`${this.apiUrl}/Match/GetTALXInfo?&resultID=${resultID}&clientID=${clientID}&caseNo=${caseNo}&histConnId=
    ${histConnId}&sessionId=${sessionId}&posRoleId=${posRoleId}&centerId=${centerId}&groupId=${groupId}`);
  }
  //GetTALXInfo(string resultID, string clientID, string caseNo, int histConnId, int sessionId, string posRoleId, string centerId, int groupId)

  GetNYCVitalStats(    
    caseNo: string,
    clientID: string,    
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ): Observable<VitalStats[]> {
    return this.http.get<
    VitalStats[]
    >(`${this.apiUrl}/Match/GetNYCVitalStats?caseNo=${caseNo}&clientID=${clientID}&histConnId=
    ${histConnId}&sessionId=${sessionId}&posRoleId=${posRoleId}&centerId=${centerId}&groupId=${groupId}`);
  }
  //GetNYCVitalStats(string caseNo, string clientID, int histConnId, int sessionId, string posRoleId, string centerId, int groupId)
  GetChildSupportIncome(
    resultID:string,
    clientID: string,     
    caseNo: string,       
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ): Observable<ChildSupportIncome[]> {
    return this.http.get<
    ChildSupportIncome[]
    >(`${this.apiUrl}/Match/GetChildSupportIncome?resultID=${resultID}&clientID=${clientID}&caseNo=${caseNo}&histConnId=
    ${histConnId}&sessionId=${sessionId}&posRoleId=${posRoleId}&centerId=${centerId}&&groupId=${groupId}`);
  }
  //GetChildSupportIncome(string resultID, string clientID, string caseNo, int histConnId, int sessionId, string posRoleId, string centerId, int groupId)
  GetNYCEmployeeInfo(
    resultID:string,
    clientID: string,     
    caseNo: string,       
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ): Observable<NYCEmployee[]> {
    return this.http.get<
    NYCEmployee[]
    >(`${this.apiUrl}/Match/GetNYCEmployeeInfo?resultID=${resultID}&clientID=${clientID}&caseNo=${caseNo}&histConnId=
    ${histConnId}&sessionId=${sessionId}&posRoleId=${posRoleId}&centerId=${centerId}&&groupId=${groupId}`);
  }
  //GetNYCEmployeeInfo(string resultID, string clientID, string caseNo, int histConnId, int sessionId, string posRoleId, string centerId, int groupId)
  GetNYCHASection8Info(
    resultID:string,
    clientID: string,     
    caseNo: string,       
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ): Observable<NYCHASec8[]> {
    return this.http.get<
    NYCHASec8[]
    >(`${this.apiUrl}/Match/GetNYCHASection8Info?resultID=${resultID}&clientID=${clientID}&caseNo=${caseNo}&histConnId=
    ${histConnId}&sessionId=${sessionId}&posRoleId=${posRoleId}&centerId=${centerId}&&groupId=${groupId}`);
  }
  //GetNYCHASection8Info(string resultID, string clientID, string caseNo, int histConnId, int sessionId, string posRoleId, string centerId, int groupId)\
  GetACCISChildcareInfo(
    resultID:string,
    clientID: string,     
    caseNo: string,       
    histConnId: number,
    sessionId: number,
    posRoleId: string,
    centerId: string,
    groupId: number
  ): Observable<ACCISChildcare[]> {
    return this.http.get<
    ACCISChildcare[]
    >(`${this.apiUrl}/Match/GetACCISChildcareInfo?resultID=${resultID}&clientID=${clientID}&caseNo=${caseNo}&histConnId=
    ${histConnId}&sessionId=${sessionId}&posRoleId=${posRoleId}&centerId=${centerId}&&groupId=${groupId}`);
  }
  //GetACCISChildcareInfo(string resultID, string clientID, string caseNo, int histConnId, int sessionId, string posRoleId, string centerId, int groupId)
}
