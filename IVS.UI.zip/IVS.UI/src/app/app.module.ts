import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/layouts/header/header.component';
import { FooterComponent } from './components/layouts/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { HPDComponent } from './components/hpd/hpd.component';
import { ACCISComponent } from './components/accis/accis.component';
import { ChildSupportExpenseComponent } from './components/child-support-expense/child-support-expense.component';
// import { ChildSupportIncomeComponent } from './components/child-support-income/child-support-income.component';
import { DHSCaresComponent } from './components/dhscares/dhscares.component';
import { MatchRunHistoryComponent } from './components/match-run-history/match-run-history.component';
import { MatchSummaryComponent } from './components/match-summary/match-summary.component';
import { NYCEmployeeComponent } from './components/nycemployee/nycemployee.component';
import { NYCHASection8Component } from './components/nychasection8/nychasection8.component';
import { NYCMarriageComponent } from './components/nycmarriage/nycmarriage.component';
import { NYCVitalStatsComponent } from './components/nycvital-stats/nycvital-stats.component';
import { SearchComponent } from './components/search/search.component';
import { TALXComponent } from './components/talx/talx.component';
import { TaxiLimousineCommissionComponent } from './components/taxi-limousine-commission/taxi-limousine-commission.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MaterialModule } from './material/material.module';
import {MatIconModule} from '@angular/material/icon'
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { HttpClientModule } from '@angular/common/http';
import { CommonComponent } from './components/common/common.component';

import { LayoutComponent } from './components/layouts/layout/layout.component';
import { SideNavComponent } from './components/layouts/side-nav/side-nav.component';
import { CommonModule } from '@angular/common';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    HPDComponent,
    ACCISComponent,
    ChildSupportExpenseComponent,
    // ChildSupportIncomeComponent,
    DHSCaresComponent,   
    MatchRunHistoryComponent,
    MatchSummaryComponent,
    NYCEmployeeComponent,
    NYCHASection8Component,
    NYCMarriageComponent,
    NYCVitalStatsComponent,
    SearchComponent,
    TALXComponent,
    TaxiLimousineCommissionComponent,
    CommonComponent,
    SideNavComponent,
    LayoutComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    NgxSpinnerModule,
    AppRoutingModule,
    MaterialModule,
    MatIconModule,
    HttpClientModule
    
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
