export const environment = {
  production: false,
  msalConfig: {
    auth: {

      clientId: 'a308eba9-3372-4e57-a931-b5124179d9b7',
      authority: 'https://login.microsoftonline.com/320c95f3-6f40-4b25-aa05-5c3137575fe9/',
    },
  },
  apiConfig: {
    scopes: ['user.read'],
    uri: 'https://graph.microsoft.com/v1.0/me',
  },
};
  // clientId: 'b5c2e510-4a17-4feb-b219-e55aa5b74144',
      // authority: 'https://login.microsoftonline.com/common',
