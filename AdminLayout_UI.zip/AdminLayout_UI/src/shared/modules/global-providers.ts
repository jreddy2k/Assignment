// global-providers.ts
import { DatePipe } from '@angular/common';

export const GLOBAL_PROVIDERS = [
  DatePipe,
  // Add other global providers here
];
