import { NgModule } from "@angular/core";
import { StringFilterByPipe } from "../Pipes/pipes";
import { DatePipe } from "@angular/common";


@NgModule({

declarations: [StringFilterByPipe],
  exports: [StringFilterByPipe]
})
export class PipesModule {}
