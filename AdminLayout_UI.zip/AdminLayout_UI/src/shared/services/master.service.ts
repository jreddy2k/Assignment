import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from './http.service';
import { FormGroups, Forms, PostResult, Roles } from '../models/Users';
import { Department } from '../../app/ir35/models/MasterData';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MasterService {
  constructor(private httpService:HttpService) { }

  GetAllDivisions() {
    return this.httpService.httpGet('api/Masters/GetAllDivisions');
  }
  AddFormGroups(model:any) {
    return this.httpService.httpPost('api/Masters/AddFormGroups',model);
  }
  AddForms(model:any) {
    return this.httpService.httpPost('api/Masters/AddForm',model);
  }
  GetAllCountry() {
    return this.httpService.httpGet('api/Masters/GetAllCountry');
  }
  DeleteDepartment(element: FormGroups) {
    return this.httpService.httpGet('');
  }


  GetAllForms(NetworkID:string,RoleID:string): Observable<any[]> {
    return this.httpService.httpGet(`api/Masters/GetAllForms?NetworkID=${NetworkID}&RoleID=${RoleID}`);
  }
  GetAllFormGroups(NetworkID:string,RoleID:string): Observable<any[]> {
    return this.httpService.httpGet(`api/Masters/GetAllFormsGroup?NetworkID=${NetworkID}&RoleID=${RoleID}`);
  }
  DeleteForms(Id:number,ModifiedBy:string,ModifiedOn:string | null): Observable<PostResult> {
    return this.httpService.httpGet(`api/Masters/DeleteForm?Id=${Id}&ModifiedBy=${ModifiedBy}&ModifiedOn=${ModifiedOn}`);
  }
  GetAllFormGroupDetails(ID:Number): Observable<any> {
    return this.httpService.httpGet(`api/Masters/GetFormGroupDetails/${ID}`);
  }
  DeleteFormsGroup(Id:number,ModifiedBy:string,ModifiedOn:string | null): Observable<PostResult> {
    return this.httpService.httpGet(`api/Masters/DeleteFormsGroup?Id=${Id}&ModifiedBy=${ModifiedBy}&ModifiedOn=${ModifiedOn}`);
  }

  GetAllRoles(): Observable<Roles[]> {
    return this.httpService.httpGet('api/Masters/GetAllRoles');
  }

  GetDepartments(): Observable<Department[]> {
    return this.httpService.httpGet(
      `api/Masters/GetDepartments/`
    );
  }


}
