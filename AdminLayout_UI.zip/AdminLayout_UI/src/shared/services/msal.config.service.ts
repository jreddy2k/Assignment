import { Injectable } from '@angular/core';
import { Configuration } from '@azure/msal-browser';

@Injectable({
  providedIn: 'root' // Provide the service globally
})
export class MsalConfigService {
  config: Configuration = {
    auth: {
      clientId: 'YOUR_CLIENT_ID', // Replace with your actual client ID
      redirectUri: 'http://localhost:4200/auth/callback', // Adjust redirect URI as needed
      authority: 'https://login.microsoftonline.com/common', // Common authority for Azure AD
    },
    cache: {
      cacheLocation: 'localStorage', // Use local storage for cache
    },
  };

  // Optionally add protectedResourceMap based on your API requirements
  protectedResourceMap = new Map([
    ['https://graph.microsoft.com/v1.0/me', ['user.Read']],
    // Add other protected resources with their scopes here
  ]);
}
