import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { LoginUser } from '../models/Users';
const GRAPH_ENDPOINTID = 'https://graph.microsoft.com/v1.0/me';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public loginSubject$ : Subject<LoginUser> = new Subject<LoginUser>();
  constructor(private httpClient: HttpClient) {}

  getUserProfile() {
    return this.httpClient.get<any>(GRAPH_ENDPOINTID);
  }

}
