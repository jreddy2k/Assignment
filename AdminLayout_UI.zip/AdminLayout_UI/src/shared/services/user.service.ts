import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from './http.service';
import { Employee, PostResult, UserAccess, Users } from '../models/Users';
import { SearchModel } from '../models/searchModel';
import { DCSDdls } from '../models/DCSdls';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpService: HttpService) { }

  GetUserStatus(NetworkID:string): Observable<string> {
    return this.httpService.httpGet(`api/Users/GetUserStatus?UserID=${NetworkID}`)
  }

  GetUserDetails(UserID: string): Observable<UserAccess> {
    return this.httpService.httpGet(`api/Users/GetUserDetails?UserID=${UserID}`)
  }

  GetUsersList(NetworkID:string, Role:string): Observable<Users[]> {
    return this.httpService.httpGet(`api/Users/GetUsersList?UserID=${NetworkID}&Role=${Role}`)
  }

  ReActiveUser(
    UserID: string,
    ModifiedBy: string,
    ModifiedOn: string | null
  ): Observable<string> {
    return this.httpService.httpPost(`api/Users/ReActiveUser?UserID=${UserID}&ModifiedBy=${ModifiedBy}&ModifiedOn=${ModifiedOn}`)
  }

  GetEmployeeBySearch(searchValue: string,networkId:string): Observable<Employee[]> {
    return this.httpService.httpGet(`api/Users/GetEmployeeBySearch?searchValue=${searchValue}`)
  }

  GetDCSbyLoginIDRole(User: string, Role: string): Observable<DCSDdls> {
    let searchModel = new SearchModel();
    searchModel.AddSearchByFilter('strUser', User);
    searchModel.AddSearchByFilter('Role', Role);
    return this.httpService.httpPost(
      'api/Users/GetDCSbyLoginIDRole',
      searchModel
    );
  }

  AddUser(model: UserAccess): Observable<PostResult> {

    return this.httpService.httpPost('api/Users/AddUser',model)
  }

  DeleteUser(
    Id: number,
    ModifiedBy: string,
    ModifiedOn: string | null
  ): Observable<string> {
    return this.httpService.httpPost(`api/Users/DeleteUser?Id=${Id}&ModifiedBy=${ModifiedBy}&ModifiedOn=${ModifiedOn}`)
  }

  UpdateUser(model: UserAccess): Observable<PostResult> {
    return this.httpService.httpPost('api/Users/UpdateUser',model)
  }

  GetAllUserRoles(UserID: string)
  {
    return this.httpService.httpGet(`api/Users/GetAllUserRoles?UserID=${UserID}`)
  }

  GetMenuItems(RoleCode: string): Observable<NavItem[]> {
    return this.httpService.httpGet(`api/Masters/GetNavigationItems?RoleID=${RoleCode}`);
  }
}
export class NavItem {
  MenuName!: string;
  MenuURL!: string;
  showSubItems!: boolean;
  SubItems!: NavItem[] | null;
}
