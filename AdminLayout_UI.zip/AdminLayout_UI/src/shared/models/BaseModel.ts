export class BaseModel {
    //Action: Action;

    CreatedBy!: string;

    CreatedDate?: Date | string | null;

    ModifiedBy!: string;

    ModifiedDate?: Date | string | null;
}