import { AutherizationSecurityMatrix } from './AutherizationSecurityMatrix';
import { BaseModel } from './BaseModel';


export class UserContext extends BaseModel{
  LoginId!: string;  // Equivalent to user name
  AdObjectId!: string;
    Action!: number;
    Active!: boolean;
    DisplayName!: string; 
    EmailId!: string;
    Language!: string;
    TimeZoneName!: string;
    UserId!: number;
  AutherizationSecurityMatrix!: AutherizationSecurityMatrix[]
}
