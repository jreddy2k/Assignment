export class AutherizationSecurityMatrix {

    UserId!: number;

    ApplicationId!: number;

    RoleId!: number;

    RoleCode!: string;

    AccessLevelId!: number;

    AccessLevelEntities!: string;

    DeptEntities!: string;
}
