import { Country, Divisions, Sites } from "./Users";

export class DCSDdls {
    ddlDivisisions!: Divisions[];
    ddlCountries!: Country[];
    ddlSites!: Sites[];
    ddlLocations: any;
    ddlDepts: any;
  }