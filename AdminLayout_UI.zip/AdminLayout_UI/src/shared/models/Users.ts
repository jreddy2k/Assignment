export class Users {
  ID!: number;
  EmpNo!: string;
  User_ID!: string;
  User_Email!: string;
  DisplayName!: string;
  User_Title!: string;
  // User_Preparer!: boolean;
  // User_Approver!: boolean;
  RoleCode!:string;
  ModifiedBy!: string;
  ModifiedOn!: Date | string | null;
  IsActive!: boolean;
  Division_ID !: string
}

export class UserAccessEntities {
  ID: number=0;
  User_ID!: string;
  Division_ID!:string;
  Department_ID: any | null=null ;
  DepartmentName: any| null=null;
  Departments: any  |null=null;
  ModifiedBy!: string;
  ModifiedOn!: Date | string | null;
  IsDeleted!: boolean;
  IsModified:boolean=false;
  IsEdit:boolean=false;
  IsActive!:boolean;
  index!:number ;
  RoleCode!:string;
  Country_Code!:string;
  Site_Location!:string;
  Type!:string;
  Entities!:string;
  EntitiesList!:string[]
}

export class UserAccess {
  Users: Users = new Users();
  UserAccessEntities: UserAccessEntities[] = [];
}

export class LoginUser {
  EmailAddress!: string;
  NetworkID!: string;
  DisplayName!: string;
  IsLogin: boolean = false;
}

export class UserDCLEntities {
  ID!: number;
  User_ID!: string;
  Division_ID!: string;
  Country_Code!: string;
  Site_Location!: string;

  Division_Name!: string;
  Country_Name!: string;
  Location_Name!: string;

  ModifiedBy!: string;
  ModifiedOn!: Date | string | null;
  IsActive!: boolean;

}

export class Employee {
  Sno!: number;
  EMPLOYEE_NUMBER!: string;
  LAST_NAME!: string;
  FIRST_NAME!: string;
  START_DATE!: Date | string | null;
  TERMINATIONDATE!: Date | string | null;
  JOB_TITLE_DAILY!: string;
  JOB_FAMILY!: string;
  DIRECT_INDIRECT!: string;
  SUPERVISOR_NUMBER!: string;
  SUPERVISOR_NAME!: string;
  LOCATION_NAME!: string;
  LOCATION_CODE!: string;
  COUNTRY_CODE!: string;
  COUNTRY_NAME!: string;
  ORGANIZATION_NAME!: string;
  DIVISION_CODE!: string;
  DIVISION_NAME!: string;
  EMAIL_ADDRESS!: string;
  AD_USERNAME!: string;
  ASSIGNMENT_CATEGORY!: string;
  SALARY_BASIS!: string;
  ASSIGNMENT_STATUS!: string;
  UpdatedDate!: Date | string | null;
  UpdatedBy!: string;

  DisplayName!: string;
}
export class Delegatemanager {
  Id!: number;
  User_ID!: string;
  DisplayName!: string;
  Del_UserID!: string;
  Del_DisplayName!: string;
  StartDate!: Date | string | null;
  EndDate!: Date | string | null;
  ModifiedBy!: string;
  ModifiedOn!: Date | string | null;
  IsActive!: boolean | null;
}
export class Forms {
  FormID!: number;
  GroupID!: number;
  FormName!: string;
  Country !:string;
  Division !:string;
  UpdatedOn!: Date | string  |null;
  UpdatedBy!: string;
  IsActive!: boolean;
}
export class FormGroups {
  GroupID!: number;
  GroupName!: string;
  Country !:string;
  Country_Code !:string;
  Division_Code !:string;
  Division !:string;
  UpdatedOn!: Date | string  |null;
  UpdatedBy!: string;
  IsActive!: boolean;
}
export class Divisions {
  DivisionID!: string;
  DivisionName!: string;
  DivisionCode!: string;
}
export class Country {
  ID!: number;
  Name!: string;
  Code!: string;
  RegionId!: number;
  CreatedBy!: string;
  createdDate?: string;
  ModifiedBy!: string;
  modifiedDate?: string;
  isEnabled?: boolean;
  Division_ID!:string;
}
export class Sites {
  Site_ID!: number;
  Division_ID!: string;
  Country_Code!: string;
  Site_Name!: string;
  Site_Location!: string;
  UpdatedOn!: Date;
  UpdatedBy!: string;
  IsActive: boolean = true;
}
export class PostResult {
  Id!: number;
  Status!: string;
  Message!:string;
}
export class APIResponse<T> {
  IsSuccess!: boolean;
  Data!: T;
  ErrorMessage!:string;
}
export class Roles
{

}

export class ScannedFiles {
  public SID!: number;
  public CountryCode!: string;
  public DivisionCode!: string;
  public CountryName!: string;
  public DivisionName!: string;
  public FileName!: string;
  public UpdatedOn!: Date;
  public UpdatedBy!: string;
  public CreatedOn!: Date;
  public CreatedBy!: string;
  public IsActive!: boolean;
  public Selected!:boolean;
}
export class ScannedSplitFiles {
  PageNo!: number;
  FileName!: string;
  fileContent!: string;
  SanitizedURL:any;
  PageWritten!: boolean;
}
export class HrdmForms {
  FormID!: number;
  GroupID!: number;
  FormName!: string;
  UpdatedOn!: Date | string | null;
  UpdatedBy!: string;
  IsActive!: boolean;

  GroupName!: string;
}
export class EmployeeFormsInfo {
  ID !: number;
  EmpID !: number;
  FormID !: number;
  FormGroupID !: number;
  FormName !: string ;
  Distributed !: boolean;
  CompleteStatus !: number;
  ViewStatus !: number;
  UpdatedOn !: Date | string | null;
  UpdatedBy !: string;
  IsActive !: boolean;

  GroupName !: string;
  FormCategory !: string;
  FormContent !: string;
  FileNames:string[]=[];
  FolderName!: string;
  EmailAddress!: string;
  EmployeeName!:string;
  Status!:string
}
