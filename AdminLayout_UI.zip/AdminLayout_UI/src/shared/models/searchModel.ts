export class SearchModel {
  SearchBy: any = {};

  AddSearchByFilter(Key: string, Value: string) {
    this.SearchBy[Key] = Value;
  }
}
