import { Routes } from '@angular/router';
import { HeaderLayoutComponent } from './layout/header-layout/header-layout.component';
import { SidebarLayoutComponent } from './layout/sidebar-layout/sidebar-layout.component';
export const routes: Routes = [
  {
    path: '',
    component: HeaderLayoutComponent,
    children: [
      {
        path: 'home'
        ,
        loadChildren: () =>
          import('./layout/header/header.module').then((m) => m.HeaderModule),
      },
    ],
  },
  {
    path: '',
    component: SidebarLayoutComponent,
    children: [
      {
        path: 'side',
        loadChildren: () =>
          import('./layout/sidebar/sidebar.module').then((m) => m.SidebarModule),
      },
    ],
  },
];
