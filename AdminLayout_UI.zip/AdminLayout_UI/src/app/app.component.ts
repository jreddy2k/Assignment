import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {
  MsalBroadcastService,
  MsalGuardConfiguration,
  MsalService,
  MSAL_GUARD_CONFIG,
} from '@azure/msal-angular';
import { InteractionStatus, RedirectRequest } from '@azure/msal-browser';
import { NgxSpinnerService } from 'ngx-spinner';
import { filter, Subject, takeUntil } from 'rxjs';
import { SidebarLayoutComponent } from './layout/sidebar-layout/sidebar-layout.component';
import { MaterialModule } from './material/material.module';

@Component({
  selector: 'app-root',
  standalone:true,
  imports:[RouterOutlet,SidebarLayoutComponent,MaterialModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {


  constructor(
    @Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
    private msalBroadCastService: MsalBroadcastService,
    private msalService: MsalService,
  ) {}
  ngOnInit(): void {
  }

  getProfile() {
    return;
  }
  logout() {
    this.msalService.logoutRedirect();
  }

}
