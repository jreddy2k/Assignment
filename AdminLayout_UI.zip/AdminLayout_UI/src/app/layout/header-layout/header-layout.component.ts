import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { MaterialModule } from '../../material/material.module';

@Component({
  selector: 'app-header-layout',
  standalone:true,
  imports:[RouterOutlet,MaterialModule],

  templateUrl: './header-layout.component.html',
})
export class HeaderLayoutComponent {

}
