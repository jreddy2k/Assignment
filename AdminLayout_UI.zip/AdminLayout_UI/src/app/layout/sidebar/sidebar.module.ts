import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SidebarRoutingModule } from './sidebar-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OperationComponent } from './operation/operation.component';

@NgModule({
  declarations: [DashboardComponent,OperationComponent],
  imports: [
    CommonModule,
    SidebarRoutingModule,  ]
})
export class SidebarModule { }
