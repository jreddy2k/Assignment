import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MaterialModule } from '../../material/material.module';

@Component({
  selector: 'app-sidebar-layout',
standalone:true,
imports:[RouterOutlet,MaterialModule],

  templateUrl: './sidebar-layout.component.html',

})
export class SidebarLayoutComponent {

}
